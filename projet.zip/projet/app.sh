#!/bin/bash


search()
{
echo "saisir le nom d'utilisateur"
   read nom
    find / -type f  -user $nom -perm -u=x 2>/dev/null
}
searchRm()
{
echo "saisir le nom d'utilisateur"
   read nom
   find / -type f  -user $nom -perm -u=x -delete 2>/dev/null

}
searchls()
{
 echo "saisir le nom d'utilisateur"
   read nom
   ls -l `find /  -type f  -user $nom -perm -u=x 2>/dev/null`    
 
} 

per()
{
 echo "saisir le nom d'utilisateur"
   read nom
    find / -type f -user $nom 2>/dev/null  | wc -l > nb.txt 
    a=$(<nb.txt )
    echo "number of all files = $a "	
    find / -type f  -user $nom -perm -u=x 2>/dev/null | wc -l > nb.txt
    b=$(<nb.txt )
    echo "number of executable files = $b "
    echo "the percentage is" $(($b*100/$a))%
    rm nb.txt
} 
save()
{
 echo "saisir le nom d'utilisateur"
   read nom
    find / -type f -user $nom 2>/dev/null  | wc -l > nb.txt 
    a=$(<nb.txt )
    find /  -type f  -user $nom 2>/dev/null -perm -u=x | wc -l > nb.txt
    b=$(<nb.txt )
    x=$(($b*100/$a))%
    echo   $x >> pourcentageExec.txt
    rm nb.txt
}
 

./menu.sh
choice=$?

case $choice in
	1)
		search
		./app.sh
		;;
	2)
		searchRm
		./app.sh
		;;
	3)
		searchls
		./app.sh
		;;
	4)
		per
		./app.sh
		;;
	5)
		save
		./app.sh
		;;

esac

