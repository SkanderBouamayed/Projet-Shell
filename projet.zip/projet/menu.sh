#!/bin/bash
files=$(yad --width 100 --height 100 --title " Sujet 18 Fourat Chaachoui et skander bouamayed" \
    --image=""\
    --button="-search":1\
    --button="-search-rm":2\
    --button="-search-ls":3\
    --button="-per":4\
    --button="-s":5\
    --on-top \
    --center \
)


